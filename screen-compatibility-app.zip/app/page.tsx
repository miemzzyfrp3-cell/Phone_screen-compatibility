"use client"

import { useState, useMemo } from "react"
import { SearchBar } from "@/components/search-bar"
import { BrandSelector } from "@/components/brand-selector"
import { ModelList } from "@/components/model-list"
import { CompatibilityResult } from "@/components/compatibility-result"
import { getAllBrands, getModelsByBrand, searchScreens, type ScreenGroup } from "@/lib/screen-data"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Smartphone } from "lucide-react"

export default function Home() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedBrand, setSelectedBrand] = useState<string | null>(null)
  const [selectedScreen, setSelectedScreen] = useState<ScreenGroup | null>(null)

  const brands = useMemo(() => getAllBrands(), [])

  const displayedModels = useMemo(() => {
    if (searchQuery.trim()) {
      return searchScreens(searchQuery)
    }
    if (selectedBrand) {
      return getModelsByBrand(selectedBrand)
    }
    return []
  }, [searchQuery, selectedBrand])

  const handleSelectBrand = (brand: string) => {
    setSelectedBrand(brand)
    setSearchQuery("")
    setSelectedScreen(null)
  }

  const handleSearch = (query: string) => {
    setSearchQuery(query)
    if (query.trim()) {
      setSelectedBrand(null)
    }
    setSelectedScreen(null)
  }

  const handleBack = () => {
    if (selectedScreen) {
      setSelectedScreen(null)
    } else if (selectedBrand || searchQuery) {
      setSelectedBrand(null)
      setSearchQuery("")
    }
  }

  const showBrandSelector = !selectedBrand && !searchQuery.trim() && !selectedScreen
  const showModelList = (selectedBrand || searchQuery.trim()) && !selectedScreen
  const showResult = selectedScreen !== null

  return (
    <main className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-3">
            {(selectedBrand || searchQuery.trim() || selectedScreen) && (
              <Button variant="ghost" size="icon" onClick={handleBack}>
                <ArrowLeft className="h-5 w-5" />
              </Button>
            )}
            <div className="flex items-center gap-2">
              <div className="bg-primary text-primary-foreground p-2 rounded-lg">
                <Smartphone className="h-5 w-5" />
              </div>
              <div>
                <h1 className="font-bold text-lg leading-tight">Screen Finder</h1>
                <p className="text-xs text-muted-foreground">LCD Compatibility Helper</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Content */}
      <div className="container mx-auto px-4 py-6">
        {/* Search Bar - Always visible except on result page */}
        {!showResult && (
          <div className="mb-6">
            <SearchBar value={searchQuery} onChange={handleSearch} placeholder="Search any phone model..." />
          </div>
        )}

        {/* Brand Selector */}
        {showBrandSelector && (
          <div className="space-y-4">
            <h2 className="font-semibold text-lg">Select Brand</h2>
            <BrandSelector brands={brands} selectedBrand={selectedBrand} onSelectBrand={handleSelectBrand} />
          </div>
        )}

        {/* Model List */}
        {showModelList && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="font-semibold text-lg">
                {searchQuery.trim() ? `Search Results (${displayedModels.length})` : selectedBrand}
              </h2>
            </div>
            <ModelList models={displayedModels} onSelectModel={setSelectedScreen} />
          </div>
        )}

        {/* Compatibility Result */}
        {showResult && selectedScreen && (
          <CompatibilityResult screen={selectedScreen} onBack={() => setSelectedScreen(null)} />
        )}
      </div>

      {/* Footer */}
      <footer className="border-t mt-auto">
        <div className="container mx-auto px-4 py-4">
          <p className="text-xs text-center text-muted-foreground">
            Screen Compatibility Helper • For Mobile Repair Technicians
          </p>
        </div>
      </footer>
    </main>
  )
}

"use client"

import { Button } from "@/components/ui/button"

interface BrandSelectorProps {
  brands: string[]
  selectedBrand: string | null
  onSelectBrand: (brand: string) => void
}

const brandIcons: Record<string, string> = {
  Samsung: "📱",
  Motorola: "📲",
  Xiaomi: "🔴",
  "Oppo/Realme": "🟢",
  Vivo: "🔵",
  "Huawei/Honor": "🟠",
  "Infinix/Tecno/Itel": "⚫",
}

export function BrandSelector({ brands, selectedBrand, onSelectBrand }: BrandSelectorProps) {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
      {brands.map((brand) => (
        <Button
          key={brand}
          variant={selectedBrand === brand ? "default" : "outline"}
          className="h-auto py-4 flex flex-col gap-2"
          onClick={() => onSelectBrand(brand)}
        >
          <span className="text-2xl">{brandIcons[brand] || "📱"}</span>
          <span className="text-xs font-medium text-center leading-tight">{brand}</span>
        </Button>
      ))}
    </div>
  )
}

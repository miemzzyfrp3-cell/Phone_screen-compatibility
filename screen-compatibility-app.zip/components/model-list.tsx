"use client"

import type { ScreenGroup } from "@/lib/screen-data"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ChevronRight, Package, PackageX } from "lucide-react"

interface ModelListProps {
  models: ScreenGroup[]
  onSelectModel: (model: ScreenGroup) => void
}

export function ModelList({ models, onSelectModel }: ModelListProps) {
  if (models.length === 0) {
    return (
      <div className="text-center py-12 text-muted-foreground">
        <p>No models found</p>
      </div>
    )
  }

  return (
    <div className="space-y-2">
      {models.map((model) => (
        <Card
          key={model.id}
          className="cursor-pointer hover:bg-accent/50 transition-colors"
          onClick={() => onSelectModel(model)}
        >
          <CardContent className="p-4 flex items-center justify-between">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="font-semibold truncate">{model.primaryModel}</h3>
                <Badge variant={model.inStock ? "default" : "secondary"} className="shrink-0">
                  {model.inStock ? (
                    <>
                      <Package className="h-3 w-3 mr-1" /> In Stock
                    </>
                  ) : (
                    <>
                      <PackageX className="h-3 w-3 mr-1" /> Out of Stock
                    </>
                  )}
                </Badge>
              </div>
              <p className="text-sm text-muted-foreground mt-1">
                {model.compatibleModels.length} compatible model{model.compatibleModels.length !== 1 ? "s" : ""}
              </p>
            </div>
            <ChevronRight className="h-5 w-5 text-muted-foreground shrink-0 ml-2" />
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

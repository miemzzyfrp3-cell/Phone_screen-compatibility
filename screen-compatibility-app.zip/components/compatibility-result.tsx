"use client"

import type { ScreenGroup } from "@/lib/screen-data"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Package, PackageX, Layers, Smartphone, Check } from "lucide-react"
import { Separator } from "@/components/ui/separator"

interface CompatibilityResultProps {
  screen: ScreenGroup
  onBack: () => void
}

export function CompatibilityResult({ screen, onBack }: CompatibilityResultProps) {
  return (
    <div className="space-y-4">
      <Button variant="ghost" onClick={onBack} className="mb-2">
        <ArrowLeft className="h-4 w-4 mr-2" />
        Back to list
      </Button>

      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between gap-4">
            <div>
              <CardTitle className="text-xl">{screen.primaryModel}</CardTitle>
              <p className="text-sm text-muted-foreground mt-1">{screen.brand}</p>
            </div>
            <Badge variant={screen.inStock ? "default" : "secondary"} className="shrink-0">
              {screen.inStock ? (
                <>
                  <Package className="h-3 w-3 mr-1" /> In Stock
                </>
              ) : (
                <>
                  <PackageX className="h-3 w-3 mr-1" /> Out of Stock
                </>
              )}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-2">
            <Layers className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm font-medium">Quality:</span>
            <Badge variant="outline">{screen.quality}</Badge>
          </div>

          <Separator />

          <div>
            <h4 className="font-semibold flex items-center gap-2 mb-3">
              <Smartphone className="h-4 w-4" />
              Compatible Models ({screen.compatibleModels.length})
            </h4>
            <div className="grid gap-2">
              {screen.compatibleModels.map((model, index) => (
                <div key={index} className="flex items-center gap-2 p-3 bg-accent/30 rounded-lg">
                  <Check className="h-4 w-4 text-green-600 shrink-0" />
                  <span className="text-sm">{model}</span>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-primary/5 border-primary/20">
        <CardContent className="p-4">
          <p className="text-sm text-muted-foreground">
            <strong>💡 Tip:</strong> All models listed above use the same LCD screen and can be used interchangeably.
            Check stock availability before ordering.
          </p>
        </CardContent>
      </Card>
    </div>
  )
}
